class Category < ApplicationRecord
  belongs_to :user, :optional => true
end
